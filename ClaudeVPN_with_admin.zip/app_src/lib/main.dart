import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:installed_apps/installed_apps.dart';
import 'package:sing_box/sing_box.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// Сборка для разработчика: flutter build apk --dart-define=CVPN_DEV=true
const bool kDev = bool.fromEnvironment('CVPN_DEV');
const String kSupabaseUrl = 'https://prgtcyiawabwsmnotpjq.supabase.co';
const String kSupabasePublishableKey = 'sb_publishable_ml15B508T9CJkrfFYojJ-w_VkRGPOd3';
const String kAuthRedirectUrl = 'claudevpn://login-callback/';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await Supabase.initialize(url: kSupabaseUrl, anonKey: kSupabasePublishableKey);
  await SingBox.instance.initialize(
    const SingBoxOptions(
      android: SingBoxAndroidOptions(
        notificationTitle: 'ClaudeVPN',
        showTrafficInNotification: true,
        stopActionTitle: 'Отключить',
      ),
    ),
  );
  runApp(const ClaudeVpnApp());
}

class ClaudeVpnApp extends StatelessWidget {
  const ClaudeVpnApp({super.key});

  @override
  Widget build(BuildContext context) => const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: ClaudeVpnHome(),
      );
}

class ClaudeVpnHome extends StatefulWidget {
  const ClaudeVpnHome({super.key});

  @override
  State<ClaudeVpnHome> createState() => _ClaudeVpnHomeState();
}

class _ClaudeVpnHomeState extends State<ClaudeVpnHome> {
  WebViewController? _web;
  StreamSubscription? _statsSub;
  StreamSubscription? _stateSub;
  bool _pageReady = false;
  bool _busy = false;
  StreamSubscription<AuthState>? _authSub;
  Timer? _checkTimer;
  int? _limitBytes; // сколько байт осталось по тарифу на эту сессию (null — без лимита)

  @override
  void initState() {
    super.initState();
    _authSub = Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      _sendAuthState();
    });
    _checkTimer = Timer.periodic(const Duration(minutes: 2), (_) => _validateSession());
    _init();
  }

  /// Если аккаунт удалён разработчиком — сессия становится недействительной и пользователь выходит.
  Future<void> _validateSession() async {
    final auth = Supabase.instance.client.auth;
    if (auth.currentSession == null) return;
    try {
      await auth.getUser();
    } on AuthException catch (e) {
      final code = e.statusCode ?? '';
      if (code == '401' || code == '403' || code == '404' || (e.message).toLowerCase().contains('user')) {
        try { await auth.signOut(); } catch (_) {}
        _sendAuthState(message: 'Аккаунт удалён или сессия недействительна', error: true);
      }
    } catch (_) {}
  }

  Future<void> _adminListUsers() async {
    if (!kDev) return;
    try {
      final res = await Supabase.instance.client.rpc('admin_list_users');
      _sendEvent('adminusers', {'users': res});
    } catch (e) {
      _sendEvent('adminusers', {'error': _adminErr(e)});
    }
  }

  Future<void> _adminDeleteUser(String id) async {
    if (!kDev) return;
    try {
      await Supabase.instance.client.rpc('admin_delete_user', params: {'target': id});
      _sendEvent('admindeleted', {'id': id, 'ok': true});
    } catch (e) {
      _sendEvent('admindeleted', {'id': id, 'ok': false, 'error': _adminErr(e)});
    }
  }

  String _adminErr(Object e) {
    final t = e.toString();
    if (t.contains('forbidden')) return 'Нет доступа: ваша почта не в таблице admins';
    if (t.contains('Could not find the function') || t.contains('PGRST202')) return 'Не выполнен supabase_admin.sql';
    return t.length > 160 ? t.substring(0, 160) : t;
  }

  Future<void> _init() async {
    final controller = WebViewController();
    _web = controller;
    await controller.setJavaScriptMode(JavaScriptMode.unrestricted);
    await controller.setBackgroundColor(const Color(0xFF050505));
    await controller.enableZoom(false);
    await controller.addJavaScriptChannel(
      'VpnBridge',
      onMessageReceived: (message) => _onBridge(message.message),
    );
    await controller.setNavigationDelegate(
      NavigationDelegate(
        onPageFinished: (_) {
          _pageReady = true;
          if (kDev) {
            controller.runJavaScript('window.CVPN_DEV=true;window.cvpnDev&&window.cvpnDev();');
          }
          _sendState(SingBox.instance.status.isActive ? 'connected' : 'disconnected');
          _sendAuthState();
        },
      ),
    );
    await controller.loadFlutterAsset('assets/index.html');

    _statsSub = SingBox.instance.watchConnectionStats().listen((s) {
      _sendStats({
        'download': _formatBytes(s.downloadTotal),
        'upload': _formatBytes(s.uploadTotal),
        'time': _formatDuration(s.duration),
        'rxBytes': s.downloadTotal.toInt(),
        'txBytes': s.uploadTotal.toInt(),
      });
      final lim = _limitBytes;
      if (lim != null && !_busy && (s.downloadTotal + s.uploadTotal) >= lim) {
        _limitBytes = null;
        _disconnect(reason: 'limit');
      }
    });

    _stateSub = SingBox.instance.watchConnectionState().listen((s) {
      if (s.error != null) {
        _sendState('error', s.error.toString());
      }
    });

    if (mounted) setState(() {});
  }

  void _sendAuthState({String? message, bool? error}) {
    final user = Supabase.instance.client.auth.currentUser;
    _sendEvent('authstate', {
      'authenticated': user != null,
      if (user?.email != null) 'email': user!.email,
      if (message != null) 'message': message,
      if (error != null) 'error': error,
    });
  }

  Future<void> _authSignIn(String email, String password) async {
    try {
      await Supabase.instance.client.auth.signInWithPassword(email: email.trim(), password: password);
      _sendAuthState(message: 'Вход выполнен');
    } on AuthException catch (e) {
      _sendAuthState(message: e.message, error: true);
    } catch (e) {
      _sendAuthState(message: 'Не удалось войти: $e', error: true);
    }
  }

  Future<void> _authSignUp(String email, String password) async {
    try {
      final result = await Supabase.instance.client.auth.signUp(
        email: email.trim(),
        password: password,
        emailRedirectTo: kAuthRedirectUrl,
      );
      if (result.session == null) {
        _sendAuthState(message: 'Письмо для подтверждения отправлено. Подтверди адрес и затем войди.');
      } else {
        _sendAuthState(message: 'Аккаунт создан');
      }
    } on AuthException catch (e) {
      _sendAuthState(message: e.message, error: true);
    } catch (e) {
      _sendAuthState(message: 'Не удалось создать аккаунт: $e', error: true);
    }
  }

  Future<void> _authReset(String email) async {
    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(
        email.trim(),
        redirectTo: kAuthRedirectUrl,
      );
      _sendAuthState(message: 'Письмо для сброса пароля отправлено.');
    } on AuthException catch (e) {
      _sendAuthState(message: e.message, error: true);
    } catch (e) {
      _sendAuthState(message: 'Не удалось отправить письмо: $e', error: true);
    }
  }

  String _formatBytes(num value) {
    if (value < 1024) return '${value.toInt()} B';
    if (value < 1024 * 1024) return '${(value / 1024).toStringAsFixed(1)} KB';
    if (value < 1024 * 1024 * 1024) return '${(value / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(value / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  String _formatDuration(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    return '${two(h)}:${two(m)}:${two(s)}';
  }

  Future<void> _onBridge(String raw) async {
    Map<String, dynamic> data;
    try {
      data = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final action = data['action'];
    if (action == 'copy') {
      await Clipboard.setData(ClipboardData(text: (data['text'] ?? '').toString()));
      return;
    }
    if (action == 'listApps') {
      await _listApps();
      return;
    }
    if (action == 'applyTunnel') {
      final err = await _applyRouting(_modeOf(data), _appsOf(data));
      _sendEvent('vpnapplied', {'ok': err == null, if (err != null) 'message': err});
      return;
    }
    if (action == 'authSignIn') {
      await _authSignIn((data['email'] ?? '').toString(), (data['password'] ?? '').toString());
      return;
    }
    if (action == 'authSignUp') {
      await _authSignUp((data['email'] ?? '').toString(), (data['password'] ?? '').toString());
      return;
    }
    if (action == 'authReset') {
      await _authReset((data['email'] ?? '').toString());
      return;
    }
    if (action == 'adminListUsers') {
      await _adminListUsers();
      return;
    }
    if (action == 'adminDeleteUser') {
      await _adminDeleteUser((data['id'] ?? '').toString());
      return;
    }
    if (action == 'authSignOut') {
      await Supabase.instance.client.auth.signOut();
      _sendAuthState();
      return;
    }
    if (_busy) return;
    switch (action) {
      case 'connect':
        await _connect(data);
        break;
      case 'disconnect':
        await _disconnect();
        break;
    }
  }

  String _modeOf(Map<String, dynamic> data) => (data['mode'] ?? 'all').toString();

  List<String> _appsOf(Map<String, dynamic> data) =>
      ((data['apps'] as List?) ?? const []).map((e) => e.toString()).toList();

  /// Список установленных приложений для окна «Раздельное туннелирование».
  Future<void> _listApps() async {
    try {
      final apps = await InstalledApps.getInstalledApps(excludeSystemApps: false);
      final list = apps
          .where((a) => !a.packageName.startsWith('com.zephyy.claudevpn'))
          .map((a) => {'n': a.name, 'p': a.packageName})
          .toList();
      _sendEvent('vpnapps', {'apps': list});
    } catch (e) {
      _sendEvent('vpnapps', {'apps': <Map<String, String>>[], 'error': e.toString()});
    }
  }

  /// mode: all | exclude (не туннелировать выбранные) | include (только выбранные).
  /// Возвращает null при успехе или текст ошибки.
  Future<String?> _applyRouting(String mode, List<String> apps) async {
    final proxy = mode == 'include' ? apps : <String>[];
    final bypass = mode == 'exclude' ? apps : <String>[];
    try {
      await SingBox.instance.updateRoutingRules(
        (r) => (r as dynamic).copyWith(proxyApps: proxy, bypassApps: bypass),
      );
      return null;
    } catch (_) {}
    try {
      await SingBox.instance.updateRoutingRules(
        (r) => (r as dynamic).copyWith(proxyApps: proxy.toSet(), bypassApps: bypass.toSet()),
      );
      return null;
    } catch (_) {}
    try {
      await SingBox.instance.setProxyApps(proxy);
      for (final app in bypass) {
        await SingBox.instance.addAppToBypass(app);
      }
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  /// Серверы лежат в assets/servers.json: массив sing-box outbound'ов,
  /// сконвертированный из исходного Xray-конфига. sing_box сам собирает из
  /// массива селектор `proxy` с автоматическим urltest (`auto`).
  Future<void> _connect(Map<String, dynamic> data) async {
    _busy = true;
    final lim = data['limit'];
    _limitBytes = lim is num ? lim.toInt() : null;
    _sendState('connecting');
    try {
      await _applyRouting(_modeOf(data), _appsOf(data));
      final servers = await rootBundle.loadString('assets/servers.json');
      await SingBox.instance.connect(servers);
      _sendState('connected');
    } on SingBoxException catch (e) {
      _limitBytes = null;
      _sendState('error', e.message);
    } catch (e) {
      _sendState('error', e.toString());
    } finally {
      _busy = false;
    }
  }

  Future<void> _disconnect({String? reason}) async {
    _busy = true;
    _limitBytes = null;
    try {
      await SingBox.instance.disconnect();
      _sendEvent('vpnstate', {'state': 'disconnected', if (reason != null) 'reason': reason});
    } catch (e) {
      _sendState('error', e.toString());
    } finally {
      _busy = false;
    }
  }

  void _sendEvent(String name, Map<String, dynamic> detail) {
    if (!_pageReady) return;
    final payload = jsonEncode(detail);
    _web?.runJavaScript(
      "window.dispatchEvent(new CustomEvent('$name',{detail:$payload}));",
    );
  }

  void _sendState(String state, [String? message]) =>
      _sendEvent('vpnstate', {'state': state, if (message != null) 'message': message});

  void _sendStats(Map<String, dynamic> stats) => _sendEvent('vpnstats', stats);

  @override
  void dispose() {
    _statsSub?.cancel();
    _checkTimer?.cancel();
    _authSub?.cancel();
    _stateSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_web == null) {
      return const Scaffold(
        backgroundColor: Color(0xFF050505),
        body: Center(child: CircularProgressIndicator(color: Color(0xFFFF6A1F))),
      );
    }
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      body: SafeArea(child: WebViewWidget(controller: _web!)),
    );
  }
}
