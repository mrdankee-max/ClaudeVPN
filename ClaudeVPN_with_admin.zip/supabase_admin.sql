-- Выполни один раз: Supabase -> SQL Editor -> New query -> вставь -> Run.
-- 1) Впиши СВОЮ почту (ту, под которой входишь в dev-приложение).
create table if not exists public.admins(email text primary key);
insert into public.admins(email) values ('ТВОЯ_ПОЧТА@example.com') on conflict do nothing;
alter table public.admins enable row level security;   -- политик нет: таблицу из приложения не прочитать

create or replace function public.admin_list_users()
returns table(id uuid, email text, created_at timestamptz, last_sign_in_at timestamptz)
language plpgsql security definer set search_path = public, auth as $$
begin
  if not exists (select 1 from public.admins a where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email',''))) then
    raise exception 'forbidden';
  end if;
  return query select u.id, u.email::text, u.created_at, u.last_sign_in_at from auth.users u order by u.created_at desc;
end $$;

create or replace function public.admin_delete_user(target uuid)
returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  if not exists (select 1 from public.admins a where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email',''))) then
    raise exception 'forbidden';
  end if;
  if target = auth.uid() then raise exception 'forbidden: нельзя удалить себя'; end if;
  delete from auth.users where id = target;
end $$;

revoke all on function public.admin_list_users() from public, anon;
revoke all on function public.admin_delete_user(uuid) from public, anon;
grant execute on function public.admin_list_users() to authenticated;
grant execute on function public.admin_delete_user(uuid) to authenticated;
