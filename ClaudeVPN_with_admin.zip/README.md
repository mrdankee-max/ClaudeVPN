# ClaudeVPN Android project

This project keeps the supplied ClaudeVPN HTML interface and replaces the demo connect animation / fake traffic counters with a real sing-box VPN tunnel.

## Build from GitHub Actions

1. Create a GitHub repository.
2. Upload the contents of this project ZIP so `.github/workflows/build.yml` is at the repository root and `app_src/` is beside it.
3. Push/commit to the `main` branch, or open **Actions → Build ClaudeVPN APK → Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open the completed run, find **Artifacts**, and download **ClaudeVPN-APK**.
6. Extract the ZIP artifact and install `app-release.apk` on your Android phone.

## First launch

Servers are bundled in `app_src/assets/servers.json` (converted from the Xray config; 30 VLESS+Reality+gRPC outbounds). Tap the large central button and approve Android's VPN prompt. sing-box picks the best server automatically (urltest).

To change servers, replace `servers.json` with a JSON array of sing-box outbounds.

## Important notes

- This build targets Android ARM64 (`arm64-v8a`), which is suitable for most modern Android phones. If your device is 32-bit only, the workflow needs a different target.
- First build downloads the native sing-box library and may take several minutes.
- sing_box and sing-box are GPL-3.0-or-later. Keep their license notices and comply with the license if you redistribute a modified app.
- This is a starter project. It has not been run on your physical phone yet; if Actions reports a build error, share the failed log and it can be corrected.

## Ключи подписок и версия для разработчика

- Без ключа действует бесплатный тариф: **5 ГБ в месяц** (меняется константой `FREE_GB` в `app_src/assets/index.html`).
- Ключ вида `CL-XXXXXXXXXX` (10 символов) вводится в Настройки → «Ключ». Срок и лимит ГБ зашиты в сам ключ и защищены подписью HMAC-SHA256; срок отсчитывается с момента активации.
- Сборка даёт два APK: **ClaudeVPN-APK** (обычное приложение) и **ClaudeVPN-Dev-APK** (пакет `com.zephyy.claudevpn.dev`). В dev-версии нет лимитов и есть вкладка «Генератор»: выбираете срок и ГБ — получаете ключи. Список созданных ключей хранится на этом телефоне.
- Секрет подписи — константа `KEY_SECRET` в `index.html`. Он должен быть одинаковым в обеих сборках (так и есть, это один файл). Хотите свой секрет — замените строку перед сборкой, старые ключи перестанут работать.
- Ограничения схемы без сервера: ключ нельзя отозвать, один ключ можно ввести на нескольких телефонах, а лимит можно сбросить очисткой данных приложения. Для настоящего контроля нужен сервер.

## Удаление аккаунтов (только dev-сборка)
1. Supabase → SQL Editor → выполнить `supabase_admin.sql` (предварительно впиши свою почту).
2. В dev-приложении войди под этой почтой → Настройки → Генератор → «Аккаунты пользователей» → Загрузить → Удалить.
Удалённый пользователь автоматически выходит из приложения (проверка сессии раз в 2 минуты).
